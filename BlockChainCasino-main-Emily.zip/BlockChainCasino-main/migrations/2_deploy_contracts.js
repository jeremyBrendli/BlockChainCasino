var Welcome = artifacts.require("./slots.sol");

module.exports = function(deployer){
  deployer.deploy(Welcome);
};
